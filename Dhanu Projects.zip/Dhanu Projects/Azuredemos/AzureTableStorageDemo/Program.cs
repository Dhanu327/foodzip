﻿using System;
using AzureTableStorageDemo.Services;
using System.Collections.Generic;


namespace AzureTableStorageDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("TableServices!");
            //storage account
            // var connectionString = "DefaultEndpointsProtocol=https;AccountName=dhanuazure327;AccountKey=faJthSepoHw/aGIyPRpCW/0R8MizYmMfLGvJbOX1fz7uF/3mSpkpAbmldaoEnmONrpW0QkC/uqMiAd6Qh0zsmQ==;EndpointSuffix=core.windows.net";
            //CosmosDb Api
            var connectionString = "DefaultEndpointsProtocol=https;AccountName=dhanu-tableapi;AccountKey=AykNRxR0G4oM7PifLwXARwxOKt6yelDrzeNhl48uBCozeHOKHq74wkZ31RMVKQMvB7R2gJ2RAj7e8al73dmF5w==;TableEndpoint=https://dhanu-tableapi.table.cosmos.azure.com:443/;";
            StorageTableService tableService = new StorageTableService(connectionString);

            tableService.createTable("Employees");

            Dictionary<string, object> columns = new Dictionary<string, object>()
                                                                                    {
                                                                                    { "Name", "jay" },
                                                                                    { "Age", 25 },
                                                                                    { "Designation", "Admin" },
                                                                                    { "DateOfJoin", DateTime.Now },
                                                                                    { "Salary", 55000.00 }
                                                                                    };

            var result = tableService.InsertEntity("HR", "2", columns);
            if (result != null)
            {
                Console.WriteLine("Success");
            }
            else
            {
                Console.WriteLine("Failed");
            }
        }
    }
}
