﻿
using System.Collections.Generic;
using Azure.Data.Tables;

namespace AzureTableStorageDemo.Services
{
    class StorageTableService
    {
        private TableServiceClient ServiceClient;
        private TableClient tableClient;
        public StorageTableService(string connectionString)
        {
            ServiceClient = new TableServiceClient(connectionString);
        }
        public void createTable(string tableName)
        {
            tableClient = ServiceClient.GetTableClient(tableName);
            tableClient.CreateIfNotExists();
        }
        public TableEntity InsertEntity(string partitionKey,string rowKey,Dictionary<string,object> columns)
        {
            TableEntity entity = new TableEntity(partitionKey, rowKey);
            foreach(var column in columns)
            {
                entity.Add(column.Key, column.Value);
            }
            var res = tableClient.AddEntity(entity);
            if (res.Status >= 200 && res.Status < 300) {
                return entity; 
            }

            else { 
                return null;
            }
               
        }
    }
}
