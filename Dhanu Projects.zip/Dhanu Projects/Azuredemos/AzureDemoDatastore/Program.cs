﻿using System;
using AzureDemoDatastore.Services;

namespace AzureDemoDatastore
{
    class Program
    {
        static void Main(string[] args)
        {
            var storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=dhanudemostorage2021;AccountKey=DnZS22qcvJWi4aZ9fbR9qC13+RGToAPSYaUrvxt+vN9wPanM8x7utzR3Y3WdgiLhujOgT6RoZfke7ufXX0Tosw==;EndpointSuffix=core.windows.net";
            Console.WriteLine("Hello World!");
            StorageBlobService storageService = new StorageBlobService(storageConnectionString);
            //creating container
            if(storageService.ContainerExists("myfiles") == false)
            {
                storageService.CreateContainer("myfiles");
                Console.WriteLine("New blob container created:myfiles");
            }
            else
            {
                Console.WriteLine("containeralreadyexist");
            }
            //upload a file
            string url = storageService.UploadFile(@"C:\Users\thamm\Desktop\daily codes\Demos by james.txt");
            Console.WriteLine($"file uploaded to :{url}");
        }
    }
}
