﻿using System;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System.IO;

namespace AzureDemoDatastore.Services
{
    public class StorageBlobService
    {
        private readonly BlobServiceClient serviceClient;
        private BlobContainerClient containerClient;
        public StorageBlobService(string ConnectionString)
        {
            serviceClient = new BlobServiceClient(ConnectionString);
        }
        //create a new container
        public BlobContainerClient CreateContainer(string ContainerName)
        {
            containerClient = serviceClient.CreateBlobContainer(ContainerName, PublicAccessType.Blob);
            return containerClient;
        }
        public string UploadFile(string filePath)
        {
            if (serviceClient == null)
                throw new Exception("Blob service connection not established");
            if (containerClient == null)
                throw new Exception("Blob container is not created or selected");
            string blobName = Path.GetFileName(filePath);
            FileStream fs = File.OpenRead(filePath);
            var blobClient = containerClient.GetBlobClient(blobName);
            blobClient.Upload(fs, true);
            fs.Close();
            return blobClient.Uri.AbsoluteUri;
        }
        public bool ContainerExists(string containerName)
        {
            containerClient = serviceClient.GetBlobContainerClient(containerName);
            return
                containerClient.Exists().Value;
        }
    }
}
