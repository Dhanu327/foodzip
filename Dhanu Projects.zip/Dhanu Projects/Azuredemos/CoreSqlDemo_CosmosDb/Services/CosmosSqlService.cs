﻿using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using System.Net;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using CoreSqlDemo_CosmosDb.Models;


namespace CoreSqlDemo_CosmosDb.Services
{
    public class CosmosSqlService
    {
        private CosmosClient cosmosClient;
        private Database database;
        private Container container;
        public CosmosSqlService(string cosmosUri, string accountkey)
        {
            cosmosClient = new CosmosClient(cosmosUri, accountkey);
        }
        public async Task<Database> createOrGetDatabase(string databaseId)
        {
            var response = await cosmosClient.CreateDatabaseIfNotExistsAsync(databaseId);
            if (response.StatusCode == HttpStatusCode.Created)
            {
                database = response.Database;
                Console.WriteLine("Database Created");
            }
            else if (response.StatusCode == HttpStatusCode.OK)
            {
                database = response.Database;
                Console.WriteLine("Database alredy Exist,Loading Existing Database.");
            }
            return database;
        }
        public async Task<Container> createContainer(string containerId, string PartionKey)
        {
            var response = await database.CreateContainerIfNotExistsAsync(containerId, PartionKey);
            if (response.StatusCode == HttpStatusCode.Created)
            {
                Console.WriteLine("container created");
            }
            else if (response.StatusCode == HttpStatusCode.OK)
            {
                Console.WriteLine("container Exist Just loading now");
            }
            container = response.Container;
            return container;
        }
        public async Task<Product> InsertDocument(Product product)
        {
            var response = await container.CreateItemAsync(product, new PartitionKey(product.Category));
            if (response.StatusCode == HttpStatusCode.Created)
            {
                Console.WriteLine("Item inserted in container successfully");
                return response.Resource;
            }
            else
            {
                return null;
            }
        }
        public async Task<List<Product>> GetProductsByCategory(string categoryName)
        {
            List<Product> products = new List<Product>();

            var sqlQuery = $"SELECT * FROM p WHERE p.category='{categoryName}'";
            QueryDefinition queryDefinition = new QueryDefinition(sqlQuery);
            FeedIterator<Product> queryResultSetIterator = this.container.GetItemQueryIterator<Product>(queryDefinition);
            while (queryResultSetIterator.HasMoreResults) // next batch available or not
            {
                FeedResponse<Product> feedResponse = await queryResultSetIterator.ReadNextAsync(); // read the next batch
                foreach (var product in feedResponse)
                {
                    products.Add(product);
                }
            }

            return products;
        }
        public async Task<Product> GetProductById(string id, string categoryName)
        {
            try
            {
                var resp = await container.ReadItemAsync<Product>(id, new PartitionKey(categoryName));
                Console.WriteLine("Item Found");
                return resp.Resource;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Item Not Found");
                return null;
            }
        }
        public async Task<List<Product>> GetProductsByQuery(string sqlQuery)
        {
            List<Product> products = new List<Product>();


            QueryDefinition queryDefinition = new QueryDefinition(sqlQuery);
            FeedIterator<Product> queryResultSetIterator = this.container.GetItemQueryIterator<Product>(queryDefinition);
            while (queryResultSetIterator.HasMoreResults) // next batch available or not
            {
                FeedResponse<Product> feedResponse = await queryResultSetIterator.ReadNextAsync(); // read the next batch
                foreach (var product in feedResponse)
                {
                    products.Add(product);
                }
            }

            return products;
        }
        public async Task<bool> DeleteProductById(string id, string categoryName)
        {
            try
            {
                var response = await container.DeleteItemAsync<Product>(id, new PartitionKey(categoryName));
                Console.WriteLine("Deleted successfully");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Failed to delete");
                return false;
            }
        }

    }
}

    


