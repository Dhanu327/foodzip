﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using Microsoft.Azure.Cosmos;
using System.Net;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using CoreSqlDemo_CosmosDb.Models;

namespace CoreSqlDemo_CosmosDb.Models
{
    public class Product
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("price")]
        public double Price { get; set; }

        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        [JsonProperty("mfgDate")]
        public DateTime MfgDate { get; set; }

        [JsonProperty("category")]
        public string Category { get; set; }

        [JsonProperty("suppliers")]
        public List<Supplier> suppliers { get; set; } = new List<Supplier>();
    }
    public class Supplier
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        [JsonProperty("contact")]
        public string Contact { get; set; }
    }
}
