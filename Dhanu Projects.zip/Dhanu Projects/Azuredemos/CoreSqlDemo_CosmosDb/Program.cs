﻿using System;
using CoreSqlDemo_CosmosDb.Services;
using System.Threading.Tasks;
using CoreSqlDemo_CosmosDb.Models;
using System.Collections.Generic;

namespace CoreSqlDemo_CosmosDb
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("CosmosDb_CoreSql Running!");
            var Uri = "https://localhost:8081";
            var Key = "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==";
            CosmosSqlService sqlService = new CosmosSqlService(Uri, Key);
            await sqlService.createOrGetDatabase("sampledb");

            await sqlService.createContainer("products", "/category");
            Product product = new Product
            {
                Id = Guid.NewGuid().ToString(),
                Name = "Biryani",
                Category = "Food",
                MfgDate = new DateTime(2021, 3, 21),
                Price = 190,
                Quantity = 20,
                suppliers = new List<Supplier>()
                {
                    new Supplier { Name = "abc", Address = "Kolkatha", Contact = "9874561230" },
                    new Supplier { Name = "xyz", Address = "Mumbai", Contact = "7845120369" }
                }
            };
            var insertedItem = await sqlService.InsertDocument(product);
            if (insertedItem != null)
            {
                Console.WriteLine($"id of item:{ insertedItem.Id}");
            }

            //Read and Print

            var products = await sqlService.GetProductsByCategory("Food");
            foreach (var item in products)
            {
                Console.WriteLine($"Id :{item.Id}");
                Console.WriteLine($"Name :{item.Name}");
                Console.WriteLine($"Price :{item.Price}");
                Console.WriteLine($"Quqntity :{item.Quantity}");
                Console.WriteLine($"MfgDate :{item.MfgDate}");
                Console.WriteLine($"Suppliers:{item.suppliers}");
                Console.WriteLine("-------------------------------------------------");

            }

            //Read by single product

            var Product = await sqlService.GetProductById("1e04acae-b5bc-448a-92eb-7ca281fca2a6", "Breverages");
            if (Product != null)
            {
                Console.WriteLine($"Id :{Product.Id}");
                Console.WriteLine($"Name :{Product.Name}");
                Console.WriteLine($"Price :{Product.Price}");
                Console.WriteLine($"Quqntity :{Product.Quantity}");
                Console.WriteLine($"MfgDate :{Product.MfgDate}");
            }

           // Read by Its Price

            var sqlQuery = "select * from p where p.price>=50";
            var Products = await sqlService.GetProductsByQuery(sqlQuery);
            foreach (var item in Products)
            {
                Console.WriteLine($"Id :{item.Id}");
                Console.WriteLine($"Name :{item.Name}");
                Console.WriteLine($"Price :{item.Price}");
                Console.WriteLine($"Quqntity :{item.Quantity}");
                Console.WriteLine($"MfgDate :{item.MfgDate}");
            }

            //Deleting Product
            await sqlService.DeleteProductById("1e04acae-b5bc-448a-92eb-7ca281fca2a6", "Breverages");

    }

    }
}

    

