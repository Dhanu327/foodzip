﻿using System;
using AzureQueueDemo.Services;

namespace AzureQueueDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Queue Service--send a message!");
            string queueConnectionString = "DefaultEndpointsProtocol=https;AccountName=dhanudemostorage2021;AccountKey=DnZS22qcvJWi4aZ9fbR9qC13+RGToAPSYaUrvxt+vN9wPanM8x7utzR3Y3WdgiLhujOgT6RoZfke7ufXX0Tosw==;EndpointSuffix=core.windows.net";
            string queueName = "myitems";

            StorageQueueService queueService = new StorageQueueService(queueConnectionString, queueName);
            queueService.InsertMessage("Hello,I am from C# Application");
            Console.WriteLine("Message Add To Queue");
            queueService.InsertMessage("Please...give me a permmision");
            Console.WriteLine("Message Add To Queue");
        }
    }
}
