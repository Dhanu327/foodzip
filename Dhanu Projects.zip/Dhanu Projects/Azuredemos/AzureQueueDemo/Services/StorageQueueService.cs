﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

namespace AzureQueueDemo.Services
{
    public class StorageQueueService
    {
        private readonly QueueClient queueClient;
        public StorageQueueService(string connectionString, string queueName)
        {
            queueClient = new QueueClient(connectionString, queueName);
        }
        public void InsertMessage(string message)
        {
            var result = queueClient.CreateIfNotExists();
            if (result != null)
            {
                Console.WriteLine("Queue is created");
            }
            queueClient.SendMessage(message);
        }
    }
}
