﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

namespace AzureQueueReciveDemo.Services
{
    public class StorageQueueService
    {
        private readonly QueueClient queueClient;
        public StorageQueueService(string connectionString, string queueName)
        {
            queueClient = new QueueClient(connectionString, queueName);
        }
        public string ReadNextMessage()
        {
            if (!queueClient.Exists())
            {
                Console.WriteLine("Queue doesnot Exists");
            }
            QueueProperties queueProperties = queueClient.GetProperties();
            if (queueProperties.ApproximateMessagesCount > 0)
            {
                QueueMessage[] recivedMessage = queueClient.ReceiveMessages(1);
                string messageText = recivedMessage[0].Body.ToString();
                queueClient.DeleteMessage(recivedMessage[0].MessageId, recivedMessage[0].PopReceipt);
                return messageText;

            }
            else
            {
                Console.WriteLine("Queue is empty");
                return null;
            }
        }
    }
}
