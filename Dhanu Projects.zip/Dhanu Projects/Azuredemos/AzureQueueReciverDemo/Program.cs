﻿using System;
using AzureQueueReciveDemo.Services;

namespace AzureQueueReciveDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Queue Service--send a message!");
            string queueConnectionString = "DefaultEndpointsProtocol=https;AccountName=dhanudemostorage2021;AccountKey=DnZS22qcvJWi4aZ9fbR9qC13+RGToAPSYaUrvxt+vN9wPanM8x7utzR3Y3WdgiLhujOgT6RoZfke7ufXX0Tosw==;EndpointSuffix=core.windows.net";
            string queueName = "myitems";
            StorageQueueService queueService = new StorageQueueService(queueConnectionString, queueName);
            int choice;
            do
            {
                Console.WriteLine("1)Read message");
                Console.WriteLine("2)Exit");
                Console.WriteLine("Enter your choice");
                choice = Int32.Parse(Console.ReadLine());
                if (choice == 1)
                {
                    string message = queueService.ReadNextMessage();
                    Console.WriteLine($"Message:{message}");
                }


            } while (choice != 2);


        }
    }
}
